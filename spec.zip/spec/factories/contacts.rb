FactoryBot.define do
  factory :contact do
    name { "MyString" }
    email { "MyString" }
    message { "MyText" }
  end
end
