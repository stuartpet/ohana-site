FactoryBot.define do
  factory :site_visit do
    referrer { "MyString" }
    user_agent { "MyString" }
    ip_hash { "MyString" }
  end
end
