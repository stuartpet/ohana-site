# Preview all emails at http://localhost:3000/rails/mailers/site_stats_mailer_mailer
class SiteStatsMailerPreview < ActionMailer::Preview
end
